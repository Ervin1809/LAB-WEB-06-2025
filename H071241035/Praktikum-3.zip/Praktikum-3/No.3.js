const readline = require("readline");

// buat interface input-output
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const hari = ["minggu", "senin", "selasa", "rabu", "kamis", "jumat", "sabtu"];

// mulai tanya
rl.question("Masukkan hari : ", (hariAwal) => {
  rl.question("Masukkan hari yang akan datang : ", (jumlahHariStr) => {
    let jumlahHari = parseInt(jumlahHariStr);

    // ubah input jadi huruf kecil biar konsisten
    hariAwal = hariAwal.toLowerCase();

    // cari index hari awal (langsung dipakai tanpa cek)
    let indexAwal = hari.indexOf(hariAwal);

    // hitung index hasil
    let sisa = jumlahHari % 7;
    let indexHasil = (indexAwal + sisa) % 7;

    // ambil hari tujuan
    let hariTujuan = hari[indexHasil];

    // tampilkan hasil
    console.log(`output: ${jumlahHari} hari setelah ${hariAwal} adalah ${hariTujuan}`);

    rl.close();
  });
});
